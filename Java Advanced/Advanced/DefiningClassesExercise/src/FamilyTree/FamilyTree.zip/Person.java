package FamilyTree;

public class Person {
    String name;
    String date;

    Person(String name, String date) {
        this.name = name;
        this.date = date;
    }

    public String getName() {
        return name;
    }

    public String getDate() {
        return date;
    }
}
