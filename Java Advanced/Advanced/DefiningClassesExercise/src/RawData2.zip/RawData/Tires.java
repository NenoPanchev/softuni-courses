package RawData;

public class Tires {
    double tirePressure;
    int tireAge;

    public double getTirePressure() {
        return tirePressure;
    }

    public Tires(double tirePressure, int tireAge) {
        this.tirePressure = tirePressure;
        this.tireAge = tireAge;

    }
}
