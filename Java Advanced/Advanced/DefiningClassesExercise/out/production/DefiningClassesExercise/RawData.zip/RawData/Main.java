package RawData;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int num = Integer.parseInt(scan.nextLine());
        List<Car> carList = new ArrayList<>();

        for (int i = 0; i < num; i++) {
            String[] tokens = scan.nextLine().split("\\s+");

            String model = tokens[0];
            int speed = Integer.parseInt(tokens[1]);
            int power = Integer.parseInt(tokens[2]);
            int weight = Integer.parseInt(tokens[3]);
            String cargoType = tokens[4];
            List<Tires> tiresList = new ArrayList<>();
            for (int j = 5; j < 12; j+= 2) {
                int a = j+1;
                Tires tire = new Tires(Double.parseDouble(tokens[j]), Integer.parseInt(tokens[a]));
                tiresList.add(tire);
            }
            Engine engine = new Engine(speed, power);
            Cargo cargo = new Cargo(weight, cargoType);
            Car car = new Car(model, engine, cargo, tiresList);
            carList.add(car);
        }

        String input = scan.nextLine();
        if (input.equals("fragile")) {
            List<String> model = new ArrayList<>();
            for (int i = 0; i < carList.size(); i++) {
                if (carList.get(i).getCargo().getCargoType().equals("fragile") &&
                        carList.get(i).getTire().get(i).getTirePressure() < 1) {
                    model.add(carList.get(i).getModel());
                }
            }
            model.forEach(System.out::println);
        } else if (input.equals("flamable")){
            carList.forEach(e -> {
                if (e.getCargo().getCargoType().equals("flamable") &&
                        e.getEngine().getEnginePower() > 250) {
                    System.out.printf("%s%n", e.getModel());
                }
            });
        }
    }
}
