package RawData;

import java.util.List;

public class Car {
    String model;
    Engine engine;
    Cargo cargo;
    List<Tires> tire;

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Engine getEngine() {
        return engine;
    }

    public void setEngine(Engine engine) {
        this.engine = engine;
    }

    public Cargo getCargo() {
        return cargo;
    }

    public void setCargo(Cargo cargo) {
        this.cargo = cargo;
    }

    public List<Tires> getTire() {
        return tire;
    }

    public void setTire(List<Tires> tire) {
        this.tire = tire;
    }

    public Car(String model, Engine engine, Cargo cargo, List<Tires> tire) {
        this.model = model;
        this.engine = engine;
        this.cargo = cargo;
        this.tire = tire;

    }
}
