package militaryElite;

public interface Spy extends Soldier {
    int getCodeNumber();
}
