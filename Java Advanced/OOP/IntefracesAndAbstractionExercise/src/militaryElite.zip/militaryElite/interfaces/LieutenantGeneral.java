package militaryElite.interfaces;

import java.util.Collection;

public interface LieutenantGeneral extends Private {
    Collection<Private> getPrivates();
}
