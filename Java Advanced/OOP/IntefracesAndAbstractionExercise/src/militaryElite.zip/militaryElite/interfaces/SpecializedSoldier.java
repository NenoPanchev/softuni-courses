package militaryElite.interfaces;

import militaryElite.enums.Corps;

public interface SpecializedSoldier extends Private {
    Corps getCorps();
}
