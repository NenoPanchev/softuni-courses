package militaryElite.interfaces;

public interface Mission {
}
