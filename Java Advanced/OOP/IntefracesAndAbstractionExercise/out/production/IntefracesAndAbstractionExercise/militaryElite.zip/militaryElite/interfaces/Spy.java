package militaryElite.interfaces;

public interface Spy extends Soldier {
    int getCodeNumber();
}
