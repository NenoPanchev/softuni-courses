package militaryElite;

public enum StateOfMission {
    inProgress,
    finished;
}
