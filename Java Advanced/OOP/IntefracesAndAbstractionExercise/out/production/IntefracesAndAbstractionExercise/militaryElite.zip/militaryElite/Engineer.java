package militaryElite;

import java.util.Set;

public interface Engineer {
    Set<Repair> getRepairs();
}
