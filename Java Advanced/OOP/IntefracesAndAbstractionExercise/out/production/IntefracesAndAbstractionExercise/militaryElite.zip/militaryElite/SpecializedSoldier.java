package militaryElite;

public interface SpecializedSoldier extends Private {
    Corps getCorps();
}
