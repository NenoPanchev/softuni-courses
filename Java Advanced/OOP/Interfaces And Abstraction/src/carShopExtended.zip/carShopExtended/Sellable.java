package carShopExtended;

public interface Sellable extends Car {
    Double getPrice();
}
