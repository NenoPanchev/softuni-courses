package interfaces;

public interface Attacker {
    
    int getAttackDamage();
}
