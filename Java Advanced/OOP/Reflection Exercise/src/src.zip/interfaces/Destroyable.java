package interfaces;

public interface Destroyable {
    
    int getHealth();
    
    void setHealth(int health);
}
