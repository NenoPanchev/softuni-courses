package easterRaces.repositories;

import easterRaces.repositories.interfaces.Repository;

public abstract class BaseRepository<T> implements Repository<T> {
}
