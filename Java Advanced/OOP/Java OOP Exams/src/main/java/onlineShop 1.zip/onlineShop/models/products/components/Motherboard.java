package onlineShop.models.products.components;

public class Motherboard extends BaseComponent {
    protected Motherboard(int id, String manufacturer, String model, double price, double overallPerformance, int generation) {
        super(id, manufacturer, model, price, overallPerformance, generation);
        this.setOverallPerformance(overallPerformance);
    }
    @Override
    protected void setOverallPerformance(double overallPerformance) {
        super.setOverallPerformance(getOverallPerformance() * 1.25);
    }
}
