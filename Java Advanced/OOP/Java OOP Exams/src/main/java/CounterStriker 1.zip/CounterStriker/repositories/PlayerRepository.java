package CounterStriker.repositories;

import CounterStriker.common.ExceptionMessages;
import CounterStriker.models.players.Player;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class PlayerRepository implements Repository<Player> {
    private Map<String, Player> models;

    public PlayerRepository() {
        this.models = new LinkedHashMap<>();
    }

    @Override
    public Collection<Player> getModels() {
        return Collections.unmodifiableCollection(this.models.values());
    }

    @Override
    public void add(Player model) {
        if (model == null) {
            throw new NullPointerException(ExceptionMessages.INVALID_PLAYER_REPOSITORY);
        }
        this.models.putIfAbsent(model.getUsername(), model);
    }

    @Override
    public boolean remove(Player model) {
        if (!this.models.containsKey(model.getUsername())) {
            return false;
        } else  {
            this.models.remove(model.getUsername());
            return true;
        }
    }

    @Override
    public Player findByName(String name) {
        return this.models.get(name);
    }
}
