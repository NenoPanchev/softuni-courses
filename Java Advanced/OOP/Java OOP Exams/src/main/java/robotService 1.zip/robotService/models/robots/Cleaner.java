package robotService.models.robots;

public class Cleaner extends BaseRobot {
    public Cleaner(String name, int happiness, int energy, int procedureTime) {
        super(name, happiness, energy, procedureTime);
    }
}
