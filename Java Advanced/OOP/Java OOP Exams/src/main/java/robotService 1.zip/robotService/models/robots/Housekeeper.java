package robotService.models.robots;

public class Housekeeper extends BaseRobot {
    public Housekeeper(String name, int happiness, int energy, int procedureTime) {
        super(name, happiness, energy, procedureTime);
    }
}
