package animals;

public interface ProducingSound {
    public String produceSound();
}
