package hero;

public class Main {
    public static void main(String[] args) {
        Hero hero = new Hero("Pesho", 3);
        SoulMaster mage = new SoulMaster("FireMagata", 70);
        System.out.println(hero);
        System.out.println(mage);
    }
}
