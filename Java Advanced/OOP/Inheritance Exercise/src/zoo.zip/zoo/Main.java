package zoo;

public class Main {
    public static void main(String[] args) {
        Bear bear = new Bear("Mecho");
        System.out.println(bear.getName());
    }
}
