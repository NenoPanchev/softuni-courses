package article2;

public class Articles2 {
    @Override
    public String toString() {
        return this.title + " - " + this.content + ": " + this.author;
    }

    public Articles2() {

    }

    public Articles2(String title, String content, String author) {
        this.title = title;
        this.content = content;
        this.author = author;
    }

    String title;
    String content;
    String author;
}
