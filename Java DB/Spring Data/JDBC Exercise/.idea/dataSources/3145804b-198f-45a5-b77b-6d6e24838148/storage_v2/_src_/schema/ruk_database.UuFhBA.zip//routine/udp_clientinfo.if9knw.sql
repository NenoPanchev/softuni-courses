create
    definer = root@localhost procedure udp_clientinfo(IN given_name varchar(50))
BEGIN
SELECT cl.full_name, cl.age, ba.account_number, concat('$', ba.balance) AS balance
FROM clients AS cl
JOIN bank_accounts AS ba
ON ba.client_id = cl.id
WHERE cl.full_name = given_name;
END;

