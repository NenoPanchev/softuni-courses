create
    definer = root@localhost function udf_client_cards_count(name varchar(30)) returns int
BEGIN
RETURN (SELECT COUNT(c.id)
FROM clients AS cl
JOIN bank_accounts AS ba ON ba.client_id = cl.id
JOIN cards AS c ON c.bank_account_id = ba.id
WHERE cl.full_name = `name`);
END;

