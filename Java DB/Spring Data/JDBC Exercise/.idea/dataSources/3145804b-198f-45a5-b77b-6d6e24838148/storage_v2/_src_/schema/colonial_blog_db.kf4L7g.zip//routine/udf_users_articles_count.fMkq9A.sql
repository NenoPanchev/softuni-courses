create
    definer = root@localhost function udf_users_articles_count(given_username varchar(30)) returns int
BEGIN
RETURN (SELECT COUNT(ua.user_id)
FROM users AS u
JOIN users_articles AS ua
ON ua.user_id = u.id
WHERE u.username = given_username);
END;

