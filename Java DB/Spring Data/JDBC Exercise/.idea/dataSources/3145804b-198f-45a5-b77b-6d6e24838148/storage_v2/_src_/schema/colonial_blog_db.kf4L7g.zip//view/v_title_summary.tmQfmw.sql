create definer = root@localhost view v_title_summary as
select `a`.`id` AS `id`, `a`.`title` AS `title`, concat(substr(`a`.`content`, 1, 20), '...') AS `summary`
from `colonial_blog_db`.`articles` `a`
order by char_length(`a`.`content`) desc
limit 3;

