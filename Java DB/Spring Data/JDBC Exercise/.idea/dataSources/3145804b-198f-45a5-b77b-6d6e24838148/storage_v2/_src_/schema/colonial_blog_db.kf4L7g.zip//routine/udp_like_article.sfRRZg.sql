create
    definer = root@localhost procedure udp_like_article(IN given_username varchar(30), IN given_title varchar(30))
BEGIN 
START TRANSACTION;
	IF (SELECT COUNT(*) FROM users WHERE username = given_username) = 0 
	THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Non-existent user.';
	ROLLBACK;

	ELSEIF (SELECT COUNT(*) FROM articles WHERE title = given_title) = 0 
	THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Non-existent article.';
	ROLLBACK;
ELSE
INSERT INTO likes (article_id, user_id)
SELECT
(SELECT u.id FROM users AS u WHERE u.username = given_username),
(SELECT a.id FROM articles AS a WHERE a.title = given_title);
END IF;
END;

