package com.example.battleships.model.entity;

public enum CategoryNameEnum {
    BATTLE, CARGO, PATROL
}
