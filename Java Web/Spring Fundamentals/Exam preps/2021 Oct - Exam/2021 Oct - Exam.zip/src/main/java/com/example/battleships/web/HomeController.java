package com.example.battleships.web;

import com.example.battleships.model.binding.BattleBindingModel;
import com.example.battleships.service.ShipService;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

@Controller
public class HomeController {
    private final ShipService shipService;

    public HomeController(ShipService shipService) {
        this.shipService = shipService;
    }

    @GetMapping()
    public ModelAndView index(ModelAndView modelAndView, HttpSession httpSession) {
        if (httpSession.getAttribute("user") == null) {
            modelAndView.setViewName("index");
        } else {

            modelAndView.addObject("allShips", shipService.getAllShips());
            modelAndView.addObject("attackerShipNames", shipService.getAttackerShipNames());
            modelAndView.addObject("defenderShipNames", shipService.getDefenderShipNames());
            modelAndView.setViewName("home");
        }

        return modelAndView;
    }

    @PostMapping()
    public String battle(@Valid BattleBindingModel battleBindingModel,
                         BindingResult bindingResult, RedirectAttributes redirectAttributes) {
//        if (bindingResult.hasErrors()){
//            redirectAttributes.addFlashAttribute("battleBindingModel", battleBindingModel);
//            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.battleBindingModel", bindingResult);
//
//            return "redirect:/";
//        }
        String attackerName = battleBindingModel.getAttackerShipName().toString();
        String defenderName = battleBindingModel.getDefenderShipName();
        shipService.battle(attackerName, defenderName);

        return "redirect:/";
    }

    @ModelAttribute
    public BattleBindingModel battleBindingModel() {
        return new BattleBindingModel();
    }
}
