package com.example.december2021exam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class December2021ExamApplicationTests {

    @Test
    void contextLoads() {
    }

}
