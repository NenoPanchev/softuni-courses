package com.example.december2021exam.model.entity.enums;

public enum CategoryNameEnum {
    FOOD, DRINK, HOUSEHOLD, OTHER
}
