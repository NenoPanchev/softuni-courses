package com.example.december2021exam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class December2021ExamApplication {

    public static void main(String[] args) {
        SpringApplication.run(December2021ExamApplication.class, args);
    }

}
